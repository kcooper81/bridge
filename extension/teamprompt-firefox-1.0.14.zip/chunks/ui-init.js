(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const o of document.querySelectorAll('link[rel="modulepreload"]'))s(o);new MutationObserver(o=>{for(const r of o)if(r.type==="childList")for(const d of r.addedNodes)d.tagName==="LINK"&&d.rel==="modulepreload"&&s(d)}).observe(document,{childList:!0,subtree:!0});function n(o){const r={};return o.integrity&&(r.integrity=o.integrity),o.referrerPolicy&&(r.referrerPolicy=o.referrerPolicy),o.crossOrigin==="use-credentials"?r.credentials="include":o.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function s(o){if(o.ep)return;o.ep=!0;const r=n(o);fetch(o.href,r)}})();try{}catch(e){console.error("[wxt] Failed to initialize plugins",e)}const ye=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,p=ye,g={SITE_URL:"https://teamprompt.app",SUPABASE_URL:"https://vafybxyxmpehrpqbztrc.supabase.co",SUPABASE_ANON_KEY:"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZhZnlieHl4bXBlaHJwcWJ6dHJjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzA4MzU3NjcsImV4cCI6MjA4NjQxMTc2N30.W6OiQtVpqzyueOQq6HE7_qNOTDOQgTig215zSgXYHAs"},P={prompts:"/api/extension/prompts",folders:"/api/extension/folders",teams:"/api/extension/teams",scan:"/api/extension/scan",log:"/api/extension/log",securityStatus:"/api/extension/security-status",enableShield:"/api/extension/enable-shield"};function be(){return p.runtime.getManifest().version}function B(e){return{"Content-Type":"application/json",Authorization:`Bearer ${e}`,"X-Extension-Version":be()}}const K={log(e,t,n){},warn(e,t,n){},error(e,t,n){},async dump(){return[]},async dumpJSON(){return"[]"},async clear(){}};async function k(){try{const e=await p.storage.local.get(["accessToken","refreshToken","user"]);if(K.log("session","getSession()",{hasToken:!!e.accessToken}),e.accessToken)return e}catch{}return null}async function we(e,t){const n=await fetch(`${g.SUPABASE_URL}/auth/v1/token?grant_type=password`,{method:"POST",headers:{"Content-Type":"application/json",apikey:g.SUPABASE_ANON_KEY},body:JSON.stringify({email:e,password:t})});if(!n.ok){const r=await n.json();throw K.error("login","ext login failed",{status:n.status,error:r.error_description||r.msg}),new Error(r.error_description||r.msg||"Login failed")}const s=await n.json(),o={accessToken:s.access_token,refreshToken:s.refresh_token,user:{id:s.user.id,email:s.user.email}};return K.log("login","ext login success",{userId:s.user.id}),await p.storage.local.set(o),o}async function Z(){try{const t=(await p.storage.local.get(["user"])).user?.id;await p.storage.local.set({loggedOut:!0}),await p.storage.local.remove(["accessToken","refreshToken","user"]),t&&Te(t,"session_lost")}catch{}}function Ee(){p.tabs.create({url:g.SITE_URL+"/extension/welcome?mode=signin"})}function Se(){p.tabs.create({url:g.SITE_URL+"/extension/welcome"})}function Le(){p.tabs.create({url:g.SITE_URL+"/extension/welcome?provider=google"})}function ke(){p.tabs.create({url:g.SITE_URL+"/extension/welcome?provider=github"})}async function Te(e,t){try{await fetch(`${g.SITE_URL}/api/extension/session-event`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({userId:e,event:t})})}catch{}}const V={ok:!1,status:0,data:null};let G=!1;function se(e){if(!(e instanceof Error))return!1;const t=e.message;return t.includes("Extension context invalidated")||t.includes("Receiving end does not exist")}async function $(e,t={}){if(G)return V;const n={type:"API_FETCH",url:e,method:t.method||"GET",headers:t.headers||{},body:t.body};try{const s=await p.runtime.sendMessage(n);if(s&&typeof s.ok=="boolean")return s}catch(s){if(se(s))return G=!0,V}await new Promise(s=>setTimeout(s,150));try{const s=await p.runtime.sendMessage(n);if(s&&typeof s.ok=="boolean")return s}catch(s){if(se(s))return G=!0,V}return V}function Ce(e){return Array.isArray(e)?e.map(t=>typeof t=="string"?{name:t}:typeof t=="object"&&t!==null&&"name"in t?t:{name:String(t)}):[]}function Ie(e){return e.split("_").map(t=>t.charAt(0).toUpperCase()+t.slice(1).toLowerCase()).join(" ")}function ie(e){return e.label?.trim()||Ie(e.name)}async function H(e){const t=await k();if(!t)return[];const n=new URLSearchParams;e?.query&&n.set("q",e.query),e?.templatesOnly&&n.set("templates","true"),e?.sort&&n.set("sort",e.sort),e?.favorites&&n.set("favorites","true"),e?.folderId&&n.set("folderId",e.folderId),e?.tags?.length&&n.set("tags",e.tags.join(",")),e?.limit&&n.set("limit",String(e.limit));const s=await $(`${g.SITE_URL}${P.prompts}?${n}`,{headers:B(t.accessToken)});if(s.status===401)throw new Error("SESSION_EXPIRED");if(!s.ok)throw new Error("FETCH_FAILED");return s.data?.prompts||[]}async function j(){const e=await k();if(!e)return{folders:[],unfiled_count:0,tags:[]};const t=await $(`${g.SITE_URL}${P.folders}`,{headers:B(e.accessToken)});if(t.status===401)throw new Error("SESSION_EXPIRED");if(!t.ok)throw new Error("FETCH_FAILED");const n=t.data;return{folders:n?.folders||[],unfiled_count:n?.unfiled_count||0,tags:n?.tags||[]}}async function xe(e){const t=await k();if(!t)return null;const n=await $(`${g.SITE_URL}${P.prompts}/${e}/favorite`,{method:"PATCH",headers:B(t.accessToken)});if(n.status===401)throw new Error("SESSION_EXPIRED");return n.ok?n.data?.is_favorite??null:null}async function Be(){const e=await k();if(!e)return{teams:[],org_role:"member"};const t=await $(`${g.SITE_URL}${P.teams}`,{headers:B(e.accessToken)});if(t.status===401)throw new Error("SESSION_EXPIRED");if(!t.ok)return{teams:[],org_role:"member"};const n=t.data;return{teams:n?.teams||[],org_role:n?.org_role||"member"}}async function $e(e){const t=await k();if(!t)return{success:!1,error:"Not signed in"};const n=await $(`${g.SITE_URL}${P.prompts}`,{method:"POST",headers:B(t.accessToken),body:JSON.stringify(e)});if(n.status===401)throw new Error("SESSION_EXPIRED");const s=n.data;return n.ok?{success:!0,prompt:s?.prompt}:{success:!1,error:s?.error||"Failed to create prompt"}}async function _e(e){const t=await k();if(!t)return{success:!1,error:"Not signed in"};const n=await $(`${g.SITE_URL}/api/guardrails/suggest`,{method:"POST",headers:B(t.accessToken),body:JSON.stringify(e)});if(n.status===401)throw new Error("SESSION_EXPIRED");const s=n.data;return n.ok?{success:!0,id:s?.id}:{success:!1,error:s?.error||"Failed to submit suggestion"}}function Pe(e,t){let n=e;for(const[s,o]of Object.entries(t))n=n.replaceAll(`{{${s}}}`,o);return n}async function pe(){const e=await k();if(!e)return null;try{const t=await $(`${g.SITE_URL}${P.securityStatus}`,{method:"GET",headers:B(e.accessToken)});return t.ok?t.data:null}catch{return null}}async function Ae(){const e=await k();if(!e)return null;try{const t=await $(`${g.SITE_URL}${P.enableShield}`,{method:"POST",headers:B(e.accessToken)});return t.ok?t.data:null}catch{return null}}function qe(e){return e.includes("chat.openai.com")||e.includes("chatgpt.com")?"chatgpt":e.includes("claude.ai")?"claude":e.includes("gemini.google.com")?"gemini":e.includes("copilot.microsoft.com")?"copilot":e.includes("perplexity.ai")?"perplexity":"other"}let y=[],C=null,q="",S="favorites",ae,z=!1,i,L=null,N=null,v=[],M=[];function F(){i.loginView.classList.remove("hidden"),i.mainView.classList.add("hidden"),i.detailView.classList.add("hidden"),document.getElementById("status-bar")?.classList.add("hidden")}function O(){i.loginView.classList.add("hidden"),i.mainView.classList.remove("hidden"),i.detailView.classList.add("hidden"),document.getElementById("status-bar")?.classList.remove("hidden")}function Ne(e){C=e,i.loginView.classList.add("hidden"),i.mainView.classList.add("hidden"),i.detailView.classList.remove("hidden"),document.getElementById("status-bar")?.classList.remove("hidden"),i.detailTitle.textContent=e.title;const t=document.getElementById("detail-fav-btn");if(t&&(t.innerHTML=te(e.is_favorite),t.title=e.is_favorite?"Remove from favorites":"Add to favorites"),i.detailContent.textContent=e.content,i.templateFields.innerHTML="",i.templateFields.classList.add("hidden"),e.is_template&&e.template_variables?.length>0){const n=Ce(e.template_variables);if(n.length>0){i.templateFields.classList.remove("hidden");const s=[];for(const r of n){const d=document.createElement("label");if(d.textContent=ie(r),r.description){const u=document.createElement("span");u.className="field-hint",u.textContent=r.description,d.appendChild(u)}const l=document.createElement("input");l.type="text",l.placeholder=r.description||`Enter ${ie(r).toLowerCase()}...`,l.dataset.variable=r.name,r.defaultValue&&(l.value=r.defaultValue),l.addEventListener("input",oe),i.templateFields.appendChild(d),i.templateFields.appendChild(l),s.push(l)}s.forEach((r,d)=>{r.addEventListener("keydown",l=>{l.key==="Enter"&&!l.ctrlKey&&!l.metaKey?(l.preventDefault(),d<s.length-1?s[d+1].focus():i.insertBtn.click()):l.key==="Enter"&&(l.ctrlKey||l.metaKey)&&(l.preventDefault(),i.insertBtn.click())})});const o=document.createElement("div");o.className="template-hint",o.textContent="Fill in the fields above, then insert",i.templateFields.appendChild(o),oe(),s.length>0&&requestAnimationFrame(()=>s[0].focus())}}}function oe(){if(!C)return;const e={};i.templateFields.querySelectorAll("input").forEach(n=>{const s=n.dataset.variable;e[s]=n.value||`{{${s}}}`}),i.detailContent.textContent=Pe(C.content,e)}function re(){return i.detailContent.textContent||""}function le(){const e=i.templateFields.querySelectorAll("input");let t=!1;return e.forEach(n=>{n.dataset.variable&&!n.value.trim()&&(t=!0,n.classList.add("highlight-unfilled"),setTimeout(()=>n.classList.remove("highlight-unfilled"),600))}),t}async function _(e=""){if(await k()){i.promptList.innerHTML='<div class="loading">Loading prompts...</div>',E("Fetching prompts...");try{if(e){q=e,document.getElementById("filter-bar")?.classList.add("hidden"),y=await H({query:e}),U(),E(`${y.length} result${y.length!==1?"s":""}`);return}if(q="",S==="favorites"){const n={favorites:!0};L&&(n.folderId=L),v.length>0&&(n.tags=v);const[s,o]=await Promise.all([j(),H(n)]);M=s.tags,Y(s.folders),y=o,U("favorites")}else if(S==="recent"){const n={sort:"recent",limit:30};L&&(n.folderId=L),v.length>0&&(n.tags=v);const[s,o]=await Promise.all([j(),H(n)]);M=s.tags,Y(s.folders),y=o,U("recent")}else if(S==="prompts"){await ee();return}E(`${y.length} prompt${y.length!==1?"s":""}`)}catch(n){n instanceof Error&&n.message==="SESSION_EXPIRED"?(await Z(),F(),E("Session expired — please sign in again")):(i.promptList.innerHTML='<div class="empty-state"><p>Could not reach server</p><button class="retry-btn">Retry</button></div>',E("Connection error"),i.promptList.querySelector(".retry-btn")?.addEventListener("click",()=>{_(i.searchInput.value.trim())}))}}}async function ee(){i.promptList.innerHTML='<div class="loading">Loading prompts...</div>';try{const e={};L&&(e.folderId=L),v.length>0&&(e.tags=v);const[t,n]=await Promise.all([j(),H(e)]);M=t.tags,Y(t.folders),y=n,U("folder"),E(`${y.length} prompt${y.length!==1?"s":""}`)}catch(e){e instanceof Error&&e.message==="SESSION_EXPIRED"?(await Z(),F(),E("Session expired — please sign in again")):(i.promptList.innerHTML='<div class="empty-state"><p>Could not load prompts</p><button class="retry-btn">Retry</button></div>',E("Connection error"),i.promptList.querySelector(".retry-btn")?.addEventListener("click",()=>{ee()}))}}function Y(e){document.getElementById("filter-bar")?.remove();const t=document.createElement("div");t.id="filter-bar",t.className="filter-bar";const n=document.createElement("div");n.className="filter-dropdown";const s=document.createElement("button");s.className="filter-dropdown-toggle",s.innerHTML=`<span>${N?b(N):"All categories"}</span>${ce()}`,n.appendChild(s);const o=document.createElement("div");o.className="filter-dropdown-menu hidden";const r=document.createElement("button");r.className=`filter-option${L?"":" selected"}`,r.textContent="All categories",r.addEventListener("click",()=>{L=null,N=null,A(),R()}),o.appendChild(r);for(const d of e){const l=document.createElement("button");l.className=`filter-option${L===d.id?" selected":""}`,l.textContent=d.name,l.addEventListener("click",()=>{L=d.id,N=d.name,A(),R()}),o.appendChild(l)}if(n.appendChild(o),s.addEventListener("click",d=>{d.stopPropagation();const l=!o.classList.contains("hidden");A(),l||o.classList.remove("hidden")}),t.appendChild(n),M.length>0){const d=document.createElement("div");d.className="filter-dropdown";const l=document.createElement("button");l.className="filter-dropdown-toggle";const u=v.length>0?`Tags <span class="filter-count">${v.length}</span>`:"All tags";l.innerHTML=`<span>${u}</span>${ce()}`,d.appendChild(l);const f=document.createElement("div");if(f.className="filter-dropdown-menu hidden",v.length>0){const h=document.createElement("button");h.className="filter-option filter-option-clear",h.textContent="Clear all",h.addEventListener("click",a=>{a.stopPropagation(),v=[],A(),R()}),f.appendChild(h)}for(const h of M){const a=document.createElement("label");a.className="filter-option filter-option-check";const c=document.createElement("input");c.type="checkbox",c.checked=v.includes(h),c.addEventListener("change",I=>{I.stopPropagation(),c.checked?v.includes(h)||v.push(h):v=v.filter(w=>w!==h),R()});const m=document.createElement("span");m.textContent=h,a.appendChild(c),a.appendChild(m),f.appendChild(a)}d.appendChild(f),l.addEventListener("click",h=>{h.stopPropagation();const a=!f.classList.contains("hidden");A(),a||f.classList.remove("hidden")}),t.appendChild(d)}i.promptList.parentElement?.insertBefore(t,i.promptList)}function ce(){return'<svg class="filter-chevron" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>'}function A(){document.querySelectorAll(".filter-dropdown-menu").forEach(e=>e.classList.add("hidden"))}function R(){S==="prompts"?ee():_()}function Oe(e){const t=q?ue(b(e.title),q):b(e.title),n=q?ue(b(e.description||e.content.slice(0,80)),q):b(e.description||e.content.slice(0,80));return`
    <div class="prompt-card" data-id="${b(String(e.id))}">
      <div class="prompt-card-header">
        <div class="prompt-card-title">
          ${t}
          ${e.is_template?'<span class="badge-template">Template</span>':""}
        </div>
        <div class="prompt-card-actions">
          <button class="btn-fav" data-fav-id="${b(String(e.id))}" title="${e.is_favorite?"Remove from favorites":"Add to favorites"}">${te(e.is_favorite)}</button>
          <svg class="prompt-card-arrow" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="9 18 15 12 9 6" />
          </svg>
        </div>
      </div>
      <div class="prompt-card-desc">${n}</div>
      ${e.tags?.length?`<div>${e.tags.slice(0,3).map(s=>`<span class="tag">${b(s)}</span>`).join("")}</div>`:""}
    </div>
  `}function U(e){if(y.length===0){let s="No prompts found";e==="recent"?s="No recently used prompts yet":e==="favorites"?s="No favorite prompts yet — tap the heart on any prompt":e==="folder"&&(s="This category is empty"),i.promptList.innerHTML=`<div class="empty-state"><p>${s}</p></div>`;return}const t=y.map(s=>Oe(s)).join(""),n=y.length<=1&&(S==="favorites"||S==="recent")?`<div class="onboarding-tip">
          <strong>Get started:</strong> This is a sample template. Click it to see how it works, then create your own prompts at
          <a href="${g.SITE_URL}/vault" target="_blank" rel="noopener">teamprompt.app/vault</a>.
        </div>`:"";i.promptList.innerHTML=t+n,i.promptList.querySelectorAll(".btn-fav").forEach(s=>{s.addEventListener("click",o=>{o.stopPropagation();const r=s.dataset.favId;r&&ge(r,s)})}),i.promptList.querySelectorAll(".prompt-card").forEach(s=>{s.addEventListener("click",()=>{const o=y.find(r=>r.id===s.dataset.id);o&&Ne(o)})})}function Re(){i.mainView.querySelectorAll(".tab").forEach(n=>n.classList.remove("active"));const e=i.mainView.querySelector('.tab[data-filter="guardrails"]');e&&e.classList.add("active"),S="guardrails",L=null,N=null,v=[],document.getElementById("filter-bar")?.remove(),i.searchInput.value="",i.searchInput.placeholder="Search violations...",i.promptList.classList.add("hidden");const t=document.getElementById("shield-view");t&&t.classList.remove("hidden"),J()}async function Fe(){try{const e=await p.storage.local.get(["quickSaveContent","quickSaveTimestamp"]);e.quickSaveContent&&e.quickSaveTimestamp&&(Date.now()-e.quickSaveTimestamp<5e3?me():p.storage.local.remove(["quickSaveContent","quickSaveTimestamp"]))}catch{}}async function me(){try{const t=(await p.storage.local.get(["quickSaveContent"])).quickSaveContent;if(!t||(p.storage.local.remove(["quickSaveContent","quickSaveTimestamp"]),!await k()))return;O(),await new Promise(s=>setTimeout(s,150)),await fe(t)}catch{}}async function fe(e){const t=document.getElementById("app");if(!t)return;document.getElementById("create-prompt-panel")?.remove(),z=!0;const[n,s]=await Promise.all([j(),Be()]),o=n.folders.map(f=>`<option value="${b(String(f.id))}">${b(f.name)}</option>`).join(""),r=s.teams.map(f=>`<option value="${b(String(f.id))}">${b(f.name)}</option>`).join(""),d=s.org_role,l=d!=="admin"&&d!=="manager",u=document.createElement("div");if(u.id="create-prompt-panel",u.className="create-prompt-panel",u.innerHTML=`
    <div class="panel-header">
      <span>Create Prompt</span>
      <button class="panel-close" title="Close">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
        </svg>
      </button>
    </div>
    <div class="panel-body">
      <label>Title *</label>
      <input type="text" id="cp-title" placeholder="Give your prompt a name..." />
      <label>Content *</label>
      <textarea id="cp-content" placeholder="Write your prompt here..."></textarea>
      <label>Description</label>
      <input type="text" id="cp-description" placeholder="Brief description..." />
      <label>Category</label>
      <select id="cp-folder">
        <option value="">None</option>
        ${o}
      </select>
      ${r?`
        <label>Team</label>
        <select id="cp-team">
          <option value="">Org-wide</option>
          ${r}
        </select>
      `:""}
      <label>Tone</label>
      <select id="cp-tone">
        <option value="professional">Professional</option>
        <option value="friendly">Friendly</option>
        <option value="casual">Casual</option>
        <option value="formal">Formal</option>
        <option value="technical">Technical</option>
        <option value="creative">Creative</option>
        <option value="persuasive">Persuasive</option>
      </select>
      <label>Tags</label>
      <input type="text" id="cp-tags" placeholder="Comma-separated, e.g. sales, email" />
      ${l?'<div class="panel-hint">Prompts you create will be submitted for admin approval.</div>':""}
      <div id="cp-error" class="panel-error"></div>
    </div>
    <div class="panel-actions">
      <button id="cp-cancel" class="btn-secondary">Cancel</button>
      <button id="cp-submit" class="btn-primary">${l?"Submit for Approval":"Create"}</button>
    </div>
  `,t.appendChild(u),u.querySelector(".panel-close")?.addEventListener("click",D),u.querySelector("#cp-cancel")?.addEventListener("click",D),u.querySelector("#cp-submit")?.addEventListener("click",Me),e){const f=u.querySelector("#cp-content");f&&(f.value=e);const h=u.querySelector("#cp-title");if(h){const a=e.split(`
`)[0].trim(),c=a.length>60?a.slice(0,57)+"...":a;h.value=c}requestAnimationFrame(()=>{u.querySelector("#cp-title")?.select()})}else requestAnimationFrame(()=>{u.querySelector("#cp-title")?.focus()})}function D(){z=!1,document.getElementById("create-prompt-panel")?.remove()}async function Me(){const e=document.getElementById("cp-title")?.value.trim(),t=document.getElementById("cp-content")?.value.trim(),n=document.getElementById("cp-description")?.value.trim(),s=document.getElementById("cp-folder")?.value,o=document.getElementById("cp-team")?.value,r=document.getElementById("cp-tone")?.value,d=document.getElementById("cp-tags")?.value.trim(),l=document.getElementById("cp-error"),u=document.getElementById("cp-submit");if(!e||!t){l&&(l.textContent="Title and content are required");return}const f=u?.textContent||"Create";u&&(u.disabled=!0,u.textContent="Submitting..."),l&&(l.textContent="");try{const h=d?d.split(",").map(c=>c.trim()).filter(Boolean):[],a=await $e({title:e,content:t,description:n||void 0,tags:h,folder_id:s||void 0,department_id:o||void 0,tone:r||void 0});if(a.success){D(),S="prompts",document.querySelectorAll(".tab").forEach(m=>{m.classList.toggle("active",m.dataset.filter==="prompts")}),R();const c=a.prompt?.status==="pending"?"Prompt submitted for approval!":"Prompt created!";E(c),setTimeout(()=>E("Ready"),3e3)}else l&&(l.textContent=a.error||"Failed to create prompt"),u&&(u.disabled=!1,u.textContent=f)}catch{l&&(l.textContent="Something went wrong"),u&&(u.disabled=!1,u.textContent=f)}}async function J(){const e=document.getElementById("shield-view");if(!e)return;e.innerHTML='<div class="loading">Loading security status...</div>';const t=await pe();if(he(t),!t){e.innerHTML='<div class="shield-empty">Unable to load security status</div>';return}Ve(e,t)}function De(e,t){const n=e.querySelectorAll(".shield-violation"),s=t.toLowerCase();n.forEach(o=>{const r=o.querySelector(".shield-violation-rule")?.textContent?.toLowerCase()||"",d=o.querySelector(".shield-violation-match")?.textContent?.toLowerCase()||"",l=!s||r.includes(s)||d.includes(s);o.classList.toggle("hidden",!l)})}function Ve(e,t){if(t.disabled){e.innerHTML=`
      <div class="shield-status-card shield-disabled-card">
        <div class="shield-icon-wrap disabled">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            <line x1="4" y1="4" x2="20" y2="20" stroke-width="2.5"/>
          </svg>
        </div>
        <div class="shield-status-info">
          <div class="shield-status-label">Shield Disabled</div>
          <div class="shield-status-detail">Shield has been disabled for your account by an admin. Contact your admin to re-enable protection.</div>
        </div>
      </div>
    `;return}const n=t.protected?`<div class="shield-icon-wrap protected">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
          <polyline points="9 12 11 14 15 10" stroke-width="2.5"/>
        </svg>
      </div>`:`<div class="shield-icon-wrap unprotected">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
        </svg>
      </div>`,s=t.protected?"Protected":"Not Configured",o=t.protected?`${t.activeRuleCount} active rule${t.activeRuleCount!==1?"s":""} monitoring your prompts`:"Shield scans prompts before they reach AI tools.",r=t.protected?`<div class="shield-stats">
        <div class="shield-stat">
          <div class="shield-stat-value blocked">${t.weeklyStats.blocked}</div>
          <div class="shield-stat-label">Blocked</div>
        </div>
        <div class="shield-stat">
          <div class="shield-stat-value warned">${t.weeklyStats.warned}</div>
          <div class="shield-stat-label">Warned</div>
        </div>
        <div class="shield-stat">
          <div class="shield-stat-value total">${t.weeklyStats.total}</div>
          <div class="shield-stat-label">This Week</div>
        </div>
      </div>`:"",d=t.protected?"":`<div class="shield-onboarding">
        <div class="shield-onboarding-intro">
          Catches API keys, passwords, connection strings, tokens, and other secrets before they leave your clipboard. Default policies cover AWS, GitHub, Stripe, OpenAI, Slack, and more.
        </div>
        <div class="shield-onboarding-features">
          <div class="shield-feature">
            <span class="shield-feature-icon">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
            </span>
            <span>Blocks secrets &amp; credentials</span>
          </div>
          <div class="shield-feature">
            <span class="shield-feature-icon">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
            </span>
            <span>Warns on suspicious patterns</span>
          </div>
          <div class="shield-feature">
            <span class="shield-feature-icon">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
            </span>
            <span>Logs every scan for audit</span>
          </div>
        </div>
        <button id="enable-shield-btn" class="btn-primary shield-enable-btn">Enable Default Rules</button>
        <div class="shield-onboarding-hint">Installs 11 rules covering API keys, credentials, and tokens. You can customize or add more on the dashboard.</div>
      </div>`;let l="";t.recentViolations.length>0?l=`
      <div class="shield-section-title">Recent Activity</div>
      <div class="shield-violations">${t.recentViolations.map(w=>{const W=w.actionTaken==="blocked"?"blocked":"warned",X=w.actionTaken==="blocked"?"Blocked":"Warned",T=He(w.createdAt);return`<div class="shield-violation">
        <div class="shield-violation-header">
          <span class="shield-violation-rule">${b(w.ruleName)}</span>
          <span class="shield-violation-badge ${W}">${X}</span>
        </div>
        <div class="shield-violation-meta">
          <span class="shield-violation-match">${b(w.matchedText)}</span>
          <span>${T}</span>
        </div>
      </div>`}).join("")}</div>`:t.protected&&(l='<div class="shield-empty">No violations detected this week</div>');const u=`${g.SITE_URL}/guardrails`,f=t.canManage?`<a href="${u}" target="_blank" rel="noopener" class="shield-manage-link">
        ${t.protected?"Manage guardrails on teamprompt.app":"Customize rules on teamprompt.app"}
      </a>`:t.protected?'<div class="shield-manage-link shield-managed-note">Protected by your organization&apos;s guardrails</div>':"",h=`
    <button class="suggest-rule-toggle" id="suggest-rule-toggle">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
        <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
      </svg>
      Suggest a Rule
    </button>
    <div id="suggest-rule-form" class="suggest-rule-form hidden">
      <label>Rule Name</label>
      <input type="text" id="sr-name" placeholder="e.g. Block internal project names" />
      <label>What should be blocked?</label>
      <textarea id="sr-description" placeholder="Describe in plain language what this rule should catch..."></textarea>
      <label>Category</label>
      <select id="sr-category">
        <option value="custom">Custom</option>
        <option value="pii">PII / Personal Data</option>
        <option value="secrets">Secrets / Credentials</option>
        <option value="compliance">Compliance</option>
        <option value="ip">Intellectual Property</option>
      </select>
      <label>Severity</label>
      <select id="sr-severity">
        <option value="warn">Warn (allow with warning)</option>
        <option value="block">Block (prevent sending)</option>
      </select>
      <div id="sr-error" class="panel-error"></div>
      <div class="suggest-rule-actions">
        <button id="sr-cancel" class="btn-secondary">Cancel</button>
        <button id="sr-submit" class="btn-primary">Submit</button>
      </div>
    </div>
  `;e.innerHTML=`
    <div class="shield-status-card">
      ${n}
      <div class="shield-status-info">
        <div class="shield-status-label">${s}</div>
        <div class="shield-status-detail">${o}</div>
      </div>
    </div>
    ${d}
    ${r}
    ${l}
    ${f}
    ${h}
  `;const a=e.querySelector("#enable-shield-btn");a&&a.addEventListener("click",async()=>{a.disabled=!0,a.textContent="Installing rules...";const I=await Ae();if(I?.installed)J();else if(I&&!I.installed)J();else{a.disabled=!1,a.textContent="Enable Default Rules";const w=e.querySelector(".shield-onboarding-hint");w&&(w.textContent="Something went wrong. Try again or set up on the dashboard.")}});const c=e.querySelector("#suggest-rule-toggle"),m=e.querySelector("#suggest-rule-form");c&&m&&(c.addEventListener("click",()=>{c.classList.add("hidden"),m.classList.remove("hidden"),m.querySelector("#sr-name")?.focus()}),m.querySelector("#sr-cancel")?.addEventListener("click",()=>{m.classList.add("hidden"),c.classList.remove("hidden")}),m.querySelector("#sr-submit")?.addEventListener("click",async()=>{const I=m.querySelector("#sr-name")?.value.trim(),w=m.querySelector("#sr-description")?.value.trim(),W=m.querySelector("#sr-category")?.value,X=m.querySelector("#sr-severity")?.value,T=m.querySelector("#sr-error"),x=m.querySelector("#sr-submit");if(!I||!w){T&&(T.textContent="Name and description are required");return}x&&(x.disabled=!0,x.textContent="Submitting..."),T&&(T.textContent="");try{const ne=await _e({name:I,description:w,category:W,severity:X});ne.success?(m.classList.add("hidden"),c.classList.remove("hidden"),E("Rule suggestion submitted!"),setTimeout(()=>E("Ready"),2e3)):(T&&(T.textContent=ne.error||"Failed to submit"),x&&(x.disabled=!1,x.textContent="Submit"))}catch{T&&(T.textContent="Something went wrong"),x&&(x.disabled=!1,x.textContent="Submit")}}))}function he(e){const t=document.getElementById("shield-indicator");t&&(e?.disabled?(t.classList.remove("active"),t.classList.add("disabled"),t.title="Shield disabled by admin"):e?.protected?(t.classList.add("active"),t.classList.remove("disabled"),t.title=`Protected — ${e.activeRuleCount} active rules`):(t.classList.remove("active","disabled"),t.title="Security not configured"))}function He(e){const t=Date.now()-new Date(e).getTime(),n=Math.floor(t/6e4);if(n<1)return"just now";if(n<60)return`${n}m ago`;const s=Math.floor(n/60);return s<24?`${s}h ago`:`${Math.floor(s/24)}d ago`}async function de(e,t){const n=await k();if(!(!n||!C))try{const[s]=await p.tabs.query({active:!0,currentWindow:!0}),o=qe(s?.url||"");await $(`${g.SITE_URL}${P.log}`,{method:"POST",headers:B(n.accessToken),body:JSON.stringify({ai_tool:o,prompt_text:e,prompt_id:C.id,action:"sent",metadata:{method:t,source:"extension"}})})}catch{}}function Q(e){i.insertBtn.textContent=e,i.insertBtn.classList.add("btn-error"),setTimeout(()=>{i.insertBtn.textContent="Insert into AI Tool",i.insertBtn.classList.remove("btn-error")},3e3)}function E(e){i.statusText&&(i.statusText.textContent=e)}function b(e){const t=document.createElement("div");return t.textContent=e,t.innerHTML}function ue(e,t){if(!t)return e;const n=t.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");return e.replace(new RegExp(n,"gi"),"<mark>$&</mark>")}function te(e){return`<svg class="fav-heart${e?" filled":""}" width="14" height="14" viewBox="0 0 24 24" fill="${e?"currentColor":"none"}" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>`}async function ge(e,t){t.classList.add("fav-loading");try{const n=await xe(e);if(n!==null){const s=y.find(o=>o.id===e);s&&(s.is_favorite=n),C?.id===e&&(C.is_favorite=n),t.innerHTML=te(n),t.title=n?"Remove from favorites":"Add to favorites"}}catch{}finally{t.classList.remove("fav-loading")}}function ve(e){document.documentElement.setAttribute("data-theme",e);const t=document.getElementById("theme-toggle");t&&(t.checked=e==="dark")}async function Ue(){const e=await p.storage.local.get(["theme"]);ve(e.theme||"dark")}function Je(e){i=e,i.loginBtn.addEventListener("click",async()=>{const a=i.emailInput.value.trim(),c=i.passwordInput.value;if(!a||!c){i.loginError.textContent="Email and password are required";return}i.loginBtn.disabled=!0,i.loginBtn.textContent="Signing in...",i.loginError.textContent="";try{await we(a,c),O(),_()}catch(m){i.loginError.textContent=m instanceof Error?m.message:"Login failed"}finally{i.loginBtn.disabled=!1,i.loginBtn.textContent="Sign In"}}),i.logoutBtn.addEventListener("click",async()=>{await Z(),F()}),i.signupBtn.addEventListener("click",Se),i.googleAuthBtn.addEventListener("click",Le),i.githubAuthBtn.addEventListener("click",ke),i.webLoginBtn.addEventListener("click",a=>{a.preventDefault(),Ee()}),p.storage.onChanged.addListener((a,c)=>{c==="local"&&(a.accessToken&&(a.accessToken.newValue?(O(),_()):!a.accessToken.newValue&&a.accessToken.oldValue&&F()),a.quickSaveContent?.newValue&&me())}),Fe(),i.searchInput.addEventListener("input",()=>{clearTimeout(ae),ae=setTimeout(()=>{const a=i.searchInput.value.trim();if(S==="guardrails"){const c=document.getElementById("shield-view");c&&De(c,a);return}a?_(a):(document.getElementById("filter-bar")?.classList.remove("hidden"),_())},300)}),i.mainView.querySelectorAll(".tab").forEach(a=>{a.addEventListener("click",()=>{if(i.mainView.querySelectorAll(".tab").forEach(c=>c.classList.remove("active")),a.classList.add("active"),S=a.dataset.filter||"favorites",z&&D(),L=null,N=null,v=[],document.getElementById("filter-bar")?.remove(),i.searchInput.value="",S==="guardrails"){i.searchInput.placeholder="Search violations...",i.promptList.classList.add("hidden");const c=document.getElementById("shield-view");c&&c.classList.remove("hidden"),J()}else{i.searchInput.placeholder="Search prompts...",i.promptList.classList.remove("hidden");const c=document.getElementById("shield-view");c&&c.classList.add("hidden"),_()}})});const t=document.getElementById("shield-indicator");t&&t.addEventListener("click",()=>{S!=="guardrails"&&Re()});const n=document.getElementById("add-prompt-btn");n&&n.addEventListener("click",()=>{z?D():fe()}),document.addEventListener("click",()=>{A()});const s=document.getElementById("settings-btn"),o=document.getElementById("settings-dropdown"),r=document.getElementById("sidebar-toggle"),d=document.getElementById("sidebar-toggle-label");!globalThis.chrome?.sidePanel&&d&&d.classList.add("hidden"),s&&o&&(s.addEventListener("click",a=>{a.stopPropagation(),o.classList.toggle("hidden")}),document.addEventListener("click",()=>{o.classList.add("hidden")}),o.addEventListener("click",a=>{a.stopPropagation()})),r&&(p.storage.local.get(["alwaysOpenSidebar"]).then(a=>{r.checked=!!a.alwaysOpenSidebar}),r.addEventListener("change",async()=>{const a=r.checked;if(p.storage.local.set({alwaysOpenSidebar:a}),p.runtime.sendMessage({type:"SET_SIDEBAR_BEHAVIOR",enabled:a}),a){const c=globalThis;if(c.chrome?.sidePanel){const[m]=await p.tabs.query({active:!0,currentWindow:!0});m?.id&&await c.chrome.sidePanel.open({tabId:m.id}),window.close()}}}));const u=document.getElementById("detail-fav-btn");u&&u.addEventListener("click",()=>{C&&ge(C.id,u)}),i.backBtn.addEventListener("click",()=>{O(),C=null}),i.copyBtn.addEventListener("click",async()=>{const a=re();/\{\{.+?\}\}/.test(a)&&le();try{await navigator.clipboard.writeText(a),i.copyBtn.textContent="Copied!",setTimeout(()=>i.copyBtn.textContent="Copy to Clipboard",1500)}catch{i.copyBtn.textContent="Copy failed",setTimeout(()=>i.copyBtn.textContent="Copy to Clipboard",2e3)}de(a,"clipboard")}),i.insertBtn.addEventListener("click",async()=>{const a=re();/\{\{.+?\}\}/.test(a)&&le();const[c]=await p.tabs.query({active:!0,currentWindow:!0});if(c?.id)try{(await p.tabs.sendMessage(c.id,{type:"INSERT_PROMPT",content:a}))?.success?(i.insertBtn.textContent="Inserted!",setTimeout(()=>i.insertBtn.textContent="Insert into AI Tool",1500),de(a,"insert")):Q("Could not find input field")}catch{Q("Open an AI tool page first")}else Q("Open an AI tool page first")});const f=document.getElementById("open-dashboard-btn");f&&f.addEventListener("click",()=>{p.tabs.create({url:g.SITE_URL+"/home"})});const h=document.getElementById("theme-toggle");h&&h.addEventListener("change",()=>{const a=h.checked?"dark":"light";p.storage.local.set({theme:a}),ve(a)}),Ue(),k().then(a=>{a?(O(),_(),pe().then(c=>{he(c)}),ze()):F()})}const je=10080*60*1e3;async function ze(){try{const e=await p.storage.local.get(["installDate","rateDismissed"]);if(e.rateDismissed||!e.installDate||Date.now()-e.installDate<je)return;const t=document.querySelector(".toolbar");if(!t)return;const n=document.createElement("div");n.className="rate-banner",n.innerHTML=`
      <span class="rate-banner-star">⭐</span>
      <span class="rate-banner-text"><strong>Enjoying TeamPrompt?</strong> A quick rating helps others find us!</span>
      <span class="rate-banner-actions">
        <button class="rate-banner-btn rate-yes">Rate</button>
        <button class="rate-banner-btn rate-dismiss">Later</button>
      </span>
    `,t.insertAdjacentElement("afterend",n),n.querySelector(".rate-yes")?.addEventListener("click",()=>{p.storage.local.set({rateDismissed:!0});const s=p.runtime.id,r=navigator.userAgent.includes("Firefox")?"https://addons.mozilla.org/en-US/firefox/addon/teamprompt/reviews/":`https://chromewebstore.google.com/detail/teamprompt/${s}/reviews`;p.tabs.create({url:r}),n.remove()}),n.querySelector(".rate-dismiss")?.addEventListener("click",()=>{p.storage.local.set({rateDismissed:!0}),n.remove()})}catch{}}export{p as b,Je as i};
